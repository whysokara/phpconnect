<?php
$connection = mysqli_connect("localhost", "root", "", "db_form"); // create datbase connection
//$db = mysqli_select_db("db_form", $connection); // Selecting Database
//Fetching Values from URL
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
//Insert query
$query = mysqli_query($connection, "insert into form_data(firstname, lastname, email, phone) values ('$fname', '$lname', '$email','$phone')");
echo "Form Submitted Succesfully";
mysqli_close($connection); // Connection Closed
?>